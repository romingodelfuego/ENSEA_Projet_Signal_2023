%%genBruitBB function
function outp = genBB(N, var)
    outp=randn(1,N)*sqrt(var);
end